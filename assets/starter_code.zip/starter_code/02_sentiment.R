#' 02_sentiment.R
#'
#' Analyse Sentiment in Hotel Reviews
#'

# --- Library --- #
library(readr)      # load data
library(dplyr)      # data manip 
library(tibble)     # data frames
library(tidyr)      # reshape data
library(stringr)    # work with strings
library(tidytext)   # work with text
library(vader)      # vader sentiment library 
library(tokenizers) # tokenize
library(textdata)   # sentiment libraries
library(textstem)   # stemmer 
library(yardstick)  # compare models
library(ggplot2)    # plot

# --- read data --- #
tokens <- read_csv("data/tokens.csv")

df <- read_csv("data/reviews.csv") %>%
    rownames_to_column("id")

# --- Sentiment Analysis - AFINN --- #
YOURCODE 

sentiment_afinn <-
    tidy_afinn %>%
    group_by(id) %>%
    summarise(score = sum(value, na.rm = TRUE))
    mutate(sentiment_class = case_when(
        score >= 0 ~ "positive",
        TRUE ~ "negative"
            ),
           id = as.character(id)
        )

YOURCODE 

# do our two measures align?

YOURCODE 


# --- Sentiment Analysis - BING --- #
YOURCODE 

# create a count of positive and negative words per review
tidy_bing_sentiment <-
    tidy_bing %>%
    count(sentiment, id) %>%
    mutate(id = as.numeric(id)) %>%
    arrange(id)

sentiment_bing <- 
    tidy_bing_sentiment %>%
    pivot_wider(
        names_from = sentiment,
        values_from = n,
        values_fill = 0
    ) %>%
    mutate(sentiment_bing = case_when(
        positive >= negative ~ "positive",
        TRUE ~ "negative"
    )
    ) %>%
    mutate(id = as.character(id))

# Comparisons? 
YOURCODE

# --- Sentiment Analysis - VADER --- #
YOURCODE


# how to get sentiment from this:
# focus on the compound score which is a normalization of the sum of word sentiments 
# so the output lies between -1 and 1
# cutting into pos neg using 0 as the threshold ...
# Note that the VADER authors actually suggest classifying as positive. negative and neutral
# using thresholds of +/- 0.05
vader_sents2 <- 
    vader_sents %>%
    rowid_to_column("id") %>%
    filter(word_scores != 'ERROR') %>%
    mutate(vader_class = case_when(
        compound >= 0 ~ "positive",
        TRUE ~ "negative"
    )
    ) %>% 
    select(id, vader_class) %>%
    mutate(id = as.character(id))

# Comparison?
YOURCODE


