#' 02_sentiment.R
#'
#' Analyse Sentiment in Cardiologist Reviews
#'

# --- Library --- #
library(readr)      # load data
library(dplyr)      # data manip 
library(tibble)     # data frames
library(tidyr)      # reshape data
library(stringr)    # work with strings
library(tidytext)   # work with text
library(vader)      # vader sentiment library 
library(tokenizers) # tokenize
library(textdata)   # sentiment libraries
library(textstem)   # stemmer 
library(yardstick)  # compare models
library(ggplot2)    # plot

# --- read data --- #
tokens <- read_csv("data/tokens.csv")

df <- read_csv("data/reviews.csv") %>%
    rownames_to_column("id")

# --- Sentiment Analysis - AFINN --- #

get_sentiments("afinn")

# positive
get_sentiments("afinn") %>%
    filter(value == 4)

# negative
get_sentiments("afinn") %>%
    filter(value == -4)

tidy_afinn <-
    tokens %>%
    left_join(get_sentiments("afinn"))
# inner_join(get_sentiments("afinn"))

sentiment_afinn <-
    tidy_afinn %>%
    group_by(id) %>%
    summarise(score = sum(value, na.rm = TRUE),
              score2 = mean(value, na.rm = TRUE)) %>%
    mutate(id = as.numeric(id),
           score2 = replace_na(score2, 0)) %>%
    arrange(id) %>%
    mutate(sentiment_class = case_when(
        score >= 0 ~ "positive",
        TRUE ~ "negative"
    ),
    sentiment_class2 = case_when(
        score >= 0 ~ "positive",
        TRUE ~ "negative"
    ),
    id = as.character(id)
    )

sentiment_afinn <- 
    df %>%
    select(id, hotel, polarity) %>%
    inner_join(sentiment_afinn, by = "id")

# do our two measures align?

conf_mat(sentiment_afinn, 
         sentiment_class, 
         polarity,
         dnn = c("afinn", "polarity"))

accuracy(sentiment_afinn, 
         as.factor(sentiment_class), 
         as.factor(polarity))


# --- Sentiment Analysis - BING --- #
get_sentiments("bing") %>% filter(sentiment == "positive")

tidy_bing <-
    tokens %>%
    left_join(get_sentiments("bing"))

# create a count of positive and negative words per review

# do this first
tidy_bing_sentiment <-
    tidy_bing %>%
    # filter(sentiment != "NA") %>%
    count(sentiment, id) %>%
    mutate(id = as.numeric(id)) %>%
    arrange(id)

sentiment_bing <- 
    tidy_bing_sentiment %>%
    pivot_wider(
        names_from = sentiment,
        values_from = n,
        values_fill = 0
    ) %>%
    mutate(sentiment_bing = case_when(
        positive >= negative ~ "positive",
        TRUE ~ "negative"
    )
    ) %>%
    mutate(id = as.character(id))

# compare afinn and bing?

comparison_df <-
    sentiment_afinn %>%
    select(id, sentiment_class) %>%
    mutate(id = as.character(id)) %>%
    inner_join(sentiment_bing, by = "id")

conf_mat(comparison_df, 
         sentiment_class, 
         sentiment_bing,
         dnn = c("afinn", "bing"))

accuracy(comparison_df, 
         as.factor(sentiment_class), 
         as.factor(sentiment_bing)) 

# Compare bing and the star rating?

sentiment_bing <- 
    df %>%
    select(id, hotel, polarity) %>%
    inner_join(sentiment_bing, by = "id")

# do our two measures align?
conf_mat(sentiment_bing, 
         polarity, 
         sentiment_bing,
         dnn = c("polarity", "bing"))

accuracy(sentiment_bing, 
         as.factor(sentiment_bing), 
         as.factor(polarity))

# --- Sentiment Analysis - VADER --- #
# VADER does not want a tidy df .. it wants the raw text string
# so we are gonna have different text strings

# Vader: polarity, intensity, emoticons, capitalization, punctuation and 'social media terms'
# These features include:
# A full list of Western-style emoticons ( for example - :D and :P )
# Sentiment-related acronyms ( for example - LOL and ROFL )
# Commonly used slang with sentiment value ( for example - Nah and meh )

# Five Heuristics of VADER:
#     
# Punctuation, namely the exclamation point (!), increases the magnitude of the intensity without modifying the semantic orientation. For example: “The weather is hot!!!” is more intense than “The weather is hot.”
# Capitalization, specifically using ALL-CAPS to emphasize a sentiment-relevant word in the presence of other non-capitalized words, increases the magnitude of the sentiment intensity without affecting the semantic orientation. For example: “The weather is HOT.” conveys more intensity than “The weather is hot.”
# Degree modifiers (also called intensifiers, booster words, or degree adverbs) impact sentiment intensity by either increasing or decreasing the intensity. For example: “The weather is extremely hot.” is more intense than “The weather is hot.”, whereas “The weather is slightly hot.” reduces the intensity.
# Polarity shift due to Conjunctions, The contrastive conjunction “but” signals a shift in sentiment polarity, with the sentiment of the text following the conjunction being dominant. For example: “The weather is hot, but it is bearable.” has mixed sentiment, with the latter half dictating the overall rating.
# Catching Polarity Negation, By examining the contiguous sequence of 3 items preceding a sentiment-laden lexical feature, we catch nearly 90% of cases where negation flips the polarity of the text. For example a negated sentence would be “The weather isn't really that hot.”.

# as a result VADER outperforms humans in correctly labelling sentiment 
# assigned by another human coder 
# accuracy of .96 vs .84
#

# Let's do it:

vader_sents <- 
    vader_df(df$text)


# how to get sentiment from this:
# focus on the compound score which is a normalization of the sum of word sentiments 
# so the output lies between -1 and 1
# cutting into pos neg using 0 as the threshold ...
# Note that the VADER authors actually suggest classifying as positive. negative and neutral
# using thresholds of +/- 0.05
vader_sents2 <- 
    vader_sents %>%
    rowid_to_column("id") %>%
    filter(word_scores != 'ERROR') %>%
    mutate(vader_class = case_when(
        compound >= 0 ~ "positive",
        TRUE ~ "negative"
    )
    ) %>% 
    select(id, vader_class) %>%
    mutate(id = as.character(id))

# Add back to df to compare to star ratings:
df <-
    df %>% 
    inner_join(vader_sents2, by = "id")

df %>% 
    conf_mat(polarity, 
         vader_class,
         dnn = c("polarity", "vader"))

df %>%
    accuracy(
         as.factor(polarity), 
         as.factor(vader_class)) 
