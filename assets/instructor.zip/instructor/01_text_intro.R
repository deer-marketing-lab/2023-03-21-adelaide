#' intro_text.R
#' 
#' Contributors:
#' 
#' What this file does:
#'  - Introduces students to first founding concepts in text analytics

# --- Libraries --- #
library(readr)     # read files
library(dplyr)     # data manip
library(tibble)    # work with dataframe
library(tidyr)     # data manip
library(ggplot2)   # plotting
library(stringr)   # work with strings
library(tidytext)  # work with text - main functionality
library(textstem)  # stem words
library(tokenizers) # count words
library(reshape2)  # cast from long to wide and vice versa
library(wordcloud) # plot wordclouds

# --- Load Data --- #

df <- read_csv("instructor/data/cardiologist_reviews_ratemd.csv")

# --- Counting Characters and Approx. Word Counts --- #
# INSERT CODE BELOW
# Count Words and characters
df <- 
    df %>%
    mutate(n_char = nchar(review),
           n_words = count_words(review)
    ) 

# BASIC PLOT SETUP - We'll fill this in
# length of reviews by a quick cut of individual rating
df %>%
    ggplot() +
    geom_histogram(
        aes(x = n_words)
    ) +
    scale_x_continuous(trans = 'log1p') +
    facet_wrap(~sentiment_star) +
    theme_bw()

# --- Reviews to Tokens --- #
tokens <-
    df %>%
    unnest_tokens(word, review) %>%
    select(id, doctor_name, gender, individual_rating, sentiment_star, word)

# --- Standard Stop Words --- # 
# common words ? 
common_words <-
    tokens %>%
    group_by(word) %>%
    count(sort = TRUE)

stop_words

tokens_nostop <-
    tokens %>%
    anti_join(stop_words) %>%
    filter(!str_detect(word, "[[:digit:]]+"))

common_words <- 
    tokens_nostop %>%
    group_by(word) %>%
    count(sort = TRUE)

#--- Custom Stop Words --- #
custom_stop_words <- 
    tibble(
        word = c(
            'doctor',
            'doctors',
            "dr",
            'patient',
            'patients',
            'cardiologist',
            'heart'
        ),
        lexicon = 'docs'
    )

tokens_nostop <-
    tokens_nostop %>%
    anti_join(custom_stop_words)

common_words <- 
    tokens_nostop %>%
    group_by(word) %>%
    count(sort = TRUE) %>%
    ungroup()

# Plot Common Words after stopword removal
common_words %>%
    slice_max(n, n = 25) %>%
    ggplot(aes(n, 
               reorder(word, n)
    )
    ) +
    geom_col() +
    scale_y_reordered() +
    #facet_wrap(~category, scales = "free") +
    labs(y = NULL) + 
    theme_bw()

# --- Lemmatizing --- #
tokens_lemma <- 
    tokens_nostop %>%
    mutate(word = lemmatize_words(word))

# --- Word Clouds --- #
tokens_lemma %>%
    filter(sentiment_star != "neutral") %>%
    count(word, sentiment_star, sort = TRUE) %>%
    acast(word ~ sentiment_star, value.var = "n", fill = 0) %>%
    comparison.cloud(colors = c("red", "blue"),
                     max.words = 50)


# --- Save Tokens for later --- # 
write_csv(tokens_lemma, "data/tokenized_reviews.csv")
