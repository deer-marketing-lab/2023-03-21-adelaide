#' topic_modelling.R
#' 
#' contributors: 
#'
#' What this file does"
#' - Explores the stm package for topic modelling as applied to cardiology reviews
#'

# --- Library --- #
library(readr)      # Read in Data
library(dplyr)      # Data Manipulation
library(tibble)     # Working with Dataframes
library(tidytext)   # Workhorse text as data
library(stm)        # Structural Topic Modelling
library(ggplot2)    # Plotting

# --- Load Tokenized Data --- # 
tokens <- read_csv('data/tokenized_reviews.csv')

# --- Establish a Vocab List --- #
word_counts <- 
    tokens %>%
    group_by(word) %>%
    count(sort = TRUE)  %>%
    filter(n >= 4)

# --- Create Doc-Term-Matrix --- #
tokens <- 
    tokens %>%
    filter(word %in% word_counts$word)

doc_word_counts <- 
    tokens %>%
    count(id, word) %>%
    ungroup()

# cast this to a matrix
cardio_dtm <- 
    doc_word_counts %>%
    cast_sparse(id, word, n)

# --- Model! --- #
# model
cardio_topics <-
    stm(cardio_dtm,
        # why X topics, why not, its an example
        K = 7,
        # seed fixes the random number draw
        # so we should all get the same results
        seed = 123456789)

# --- Explore Output --- #
labelTopics(cardio_topics)

# top 10 words per topic visualized
td_beta <- tidy(cardio_topics)

td_beta %>%
    group_by(topic) %>%
    top_n(10, beta) %>%
    ungroup() %>%
    mutate(topic = paste0("Topic ", topic),
           term = reorder_within(term, beta, topic)) %>%
    ggplot(aes(term, beta, fill = as.factor(topic))) +
    geom_col(alpha = 0.8, show.legend = FALSE) +
    facet_wrap(~ topic, scales = "free_y") +
    coord_flip() +
    scale_x_reordered() +
    labs(x = NULL, y = expression(beta),
         title = "Highest word probabilities for each topic",
         subtitle = "Different words are associated with different topics")

# --- Assigning Topic Labels --- #
# Suppose we want to assign human readable labels to topics:
td_beta <- 
    td_beta %>%
    mutate(topic_name = case_when(
        topic == 1 ~ "topic 1", # ie. name it something meaningful,
        topic == 2 ~ "topic 2",
        topic == 3 ~ "topic 3",
        topic == 4 ~ "topic 4",
        topic == 5 ~ "topic 5",
        topic == 6 ~ "topic 6",
        TRUE ~ "topic 7"
        )
    )

# re-do your graph from above

# --- Assigning Topics to Reviews --- #
td_gamma <- 
    tidy(cardio_topics, 
         matrix = "gamma",                    
         document_names = rownames(cardio_dtm)
    ) %>%
    arrange(as.numeric(document), desc(gamma))


# give each review its most probable topic..
reviews_gamma <- 
    td_gamma %>%
    rename(id = document) %>%
    mutate(id = as.numeric(id)) %>%
    group_by(id) %>%
    slice_max(gamma) %>%
    select(-gamma)

df <- read_csv("instructor/data/cardiologist_reviews_ratemd.csv")

df <- 
    df %>%
    left_join(reviews_gamma, by = "id")

# --- Extras --- #
# IF TIME
# can the computer pick the "right" number of topics?
topics_Kchosen <-
    stm(cardio_dtm,
        K = 0,
        # seed fixes the random number draw
        # so we should all get the same results
        seed = 123456789)

# Can we choose between our own guesses at the right topic number?
n_tops <- c(5,7,10,13,15)
set.seed(123456789)
topic_search <- searchK(cardio_dtm, K = n_tops, 
                        # N is the number of docs not included in estimation so that
                        # can evaluate model on a "fresh" set of docs
                        # we're using approx 10% of the rows
                        N = floor(0.1*nrow(cardio_dtm)))
plot(topic_search)
